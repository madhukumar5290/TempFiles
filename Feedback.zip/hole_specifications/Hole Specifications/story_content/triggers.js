function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6dxKKPSUyd0":
        Script1();
        break;
      case "6Disc5ODk6I":
        Script2();
        break;
      case "5fJ5dLP5PYS":
        Script3();
        break;
      case "6bsio2SNSc5":
        Script4();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
};
