function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5jrP7ij64rb":
        Script1();
        break;
      case "6RwaFwBM0Zb":
        Script2();
        break;
      case "5qilRC5TlU6":
        Script3();
        break;
      case "6dgqIWfzq8f":
        Script4();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
};
